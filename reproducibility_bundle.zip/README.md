# Reproducibility bundle — Pipeline B telemetry (VRIH paper)

Supporting artifacts for the quantitative claims of the paper
"VR digital twin from semantic object-state telemetry" (Pipeline B).
Each file below is a copy of the sealed artifact referenced in the text;
no numbers were re-computed for this bundle.

## Real-flight replay (sealed audit)

| File | Supports |
|---|---|
| `replay_metrics.json` | Headline real-flight numbers: semantic telemetry rate (554 POSTs, 615.8 kbps as emitted, 1671 kbps mission-normalized), detection-to-ingestion latency (n = 649, mean 38.2 ms, p95 252.9 ms, max 772 ms), H.264/H.265 video baselines (10427 / 5648 kbps) and the −84.0% / −70.4% rate reductions (Figs. "latency histogram" and "bandwidth"). |
| `ZERO_TRUST_AUDIT.md` | Audit methodology of the sealed real-flight replay (data provenance, no-synthetic-data policy). |

## Trajectory fidelity (twin vs ArduPilot reference)

| File | Supports |
|---|---|
| `trajectory/trajectory_m20_1rr.csv` | Reference trajectory (ArduPilot log, M_20_1RR flight). |
| `trajectory/trajectory_m20_1rr.meta.json` | Provenance metadata of the reference trajectory. |
| `trajectory/flight_path_log.jsonl` | Commanded twin path (world_m) and Unreal marker readback per poll. |
| `trajectory/trajectory_summary.csv` | Cross-track error summary: commanded vs reference n = 2363, mean 0.224 m, max 0.237 m (paper: 0.24 m max); Unreal readback n = 157, max 0.231 m. |

## Software-only experimental support (synthetic link profiles)

| File | Supports |
|---|---|
| `bandwidth_summary.csv` | Claim that object-state telemetry is orders of magnitude lighter than FPV video baselines (H.264/H.265/WebRTC), ~95% rate reduction in the software-only scope. |
| `latency_budget_summary.csv` | End-to-end latency budget under nominal / mild-loss / degraded link profiles (mean, p50, p95, p99). |
| `network_degradation_summary.csv` | Degradation behaviour claim: under packet loss the twin keeps prior + last validated state with visible age (visible-entity recall, false-freshness / stale / removed rates, id switches). |
| `tracking_summary.csv` | Actor-lifecycle / tracking stability claims (id switches, track fragmentation, freshness rates per link profile). |
| `contract_validation_summary.json` | Telemetry contract validation: 600 payloads / 1570 obstacles, 0 schema errors (status: pass). |

## VR rendering performance (UE5 CSV profiler captures)

| File | Supports |
|---|---|
| `vr_stereo/vr_mono.csv` | Desktop mono rendering performance of the twin. |
| `vr_stereo/vr_quest2sim_stereo.csv` | Stereo rendering cost for a Quest-2-class headset (simulated). |
| `vr_stereo/vr_quest3sim_stereo.csv` | Stereo rendering cost for a Quest-3-class headset (simulated); supports the feasibility of head-tracked stereo inspection. |

## Figure generation

| File | Supports |
|---|---|
| `make_extra_figures.py` | Script that regenerates the latency-histogram and bandwidth figures from the sealed audit artifacts (matplotlib, DejaVu Sans, 200 dpi). |

Note: `trajectory/trajectory_summary.csv` is computed from the two raw artifacts above with the point-to-polyline cross-track method of `tools/make_paper_figures.py` (`nearest_error`); it is the only derived file in the bundle.
